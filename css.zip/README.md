# Memory Game

</br>

### [Play the Game](https://ravireddy07.github.io/Project_Memory_Game/)

</br>

[![Ravi Kanth Gojur](https://img.shields.io/badge/Author-@ravireddy07-gray.svg?colorA=gray&colorB=dodgerblue&logo=github)](https://github.com/ravireddy07/) [![Maintenance](https://img.shields.io/maintenance/yes/2022?color=green&logo=github)](https://github.com/ravireddy07/)


## Google India Scholarship - Udacity Front End Web Developer Nanodegree Project

* [Instructions](#instructions)
* [Contributing](#contributing)
